package com.example.activitylc

import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // The content view pointing to the id of layout
        // in the file activity_main.xml
        val toast = Toast.makeText(getApplicationContext(), "Currently in Create mode", Toast.LENGTH_LONG).show();
    }

    override fun onStart()
    {
        super.onStart()
        // It will show a message on the screen
        // then onStart is invoked
        val toast = Toast.makeText(getApplicationContext(), "onStart Called", Toast.LENGTH_LONG).show();
    }

    override fun onResume() {
        super.onResume()
        val toast = Toast.makeText(getApplicationContext(), "onResume Called", Toast.LENGTH_LONG).show();
    }

    override fun onPause() {
        super.onPause()
        val toast = Toast.makeText(getApplicationContext(), "onPause Called", Toast.LENGTH_LONG).show();
    }

    override fun onStop() {
        super.onStop()
        val toast = Toast.makeText(getApplicationContext(), "onStop Called", Toast.LENGTH_LONG).show();
    }

    override fun onDestroy() {
        super.onDestroy()
        val toast = Toast.makeText(getApplicationContext(), "onDestroy Called", Toast.LENGTH_LONG).show();
    }
    }
